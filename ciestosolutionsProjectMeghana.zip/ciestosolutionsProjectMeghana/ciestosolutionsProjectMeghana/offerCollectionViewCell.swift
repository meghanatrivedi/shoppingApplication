//
//  offerCollectionViewCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class offerCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var backView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        prePareCell()
        // Initialization code
    }

}
extension offerCollectionViewCell{
    func prePareCell(){
        backView.backgroundColor = .clear
        backView.layer.cornerRadius = 15
        backView.layer.masksToBounds = true
    }
}
