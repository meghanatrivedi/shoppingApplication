//
//  PropulerItemTableCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class PropulerItemTableCell: UITableViewCell {
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productTitle: UILabel!
    @IBOutlet weak var ProductPrice: UILabel!
    @IBOutlet weak var heartImage: UIImageView!
    @IBOutlet weak var btnHeart: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        prePareCell()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension PropulerItemTableCell{
    func prePareCell(){
        backView.backgroundColor = .clear
        
        productImage.layer.cornerRadius = 100
        productImage.clipsToBounds = true
        
        
        productTitle.textColor = .white
        productTitle.font = UIFont.boldSystemFont(ofSize: 16.0)
        
        ProductPrice.textColor = .white
        ProductPrice.font = UIFont.systemFont(ofSize: 14.0)
    }
}
