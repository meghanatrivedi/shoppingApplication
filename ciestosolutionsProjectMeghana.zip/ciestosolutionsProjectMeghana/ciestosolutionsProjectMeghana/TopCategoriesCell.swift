//
//  TopCategoriesCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class TopCategoriesCell: UITableViewCell {

    @IBOutlet weak var collcetionView: UICollectionView!
    @IBOutlet weak var btnSeeAll: UIButton!
    @IBOutlet weak var lblTop: UILabel!
    @IBOutlet weak var backView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        prePareCell()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension TopCategoriesCell{
    func prePareCell(){
        backView.backgroundColor = .clear
        collcetionView.delegate = self
        collcetionView.dataSource = self
        
        lblTop.font = UIFont.systemFont(ofSize: 20.0)
        lblTop.textColor = .white
        lblTop.text = "Top Categories"

        
        registationCell()
    }
    func registationCell(){
        
        self.collcetionView.register(UINib(nibName: "topCategoriesCellctionViewCell", bundle: nil), forCellWithReuseIdentifier: "topCategoriesCellctionViewCell")
        
    }
}
extension TopCategoriesCell : UICollectionViewDelegate ,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : topCategoriesCellctionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "topCategoriesCellctionViewCell", for: indexPath) as! topCategoriesCellctionViewCell
        
        return cell
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//        return UIEdgeInsets(top: 1.0, left: 1.0, bottom: 1.0, right: 1.0)//here your custom value for spacing
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let lay = collectionViewLayout as! UICollectionViewFlowLayout
//        let widthPerItem = collectionView.frame.width / 1 - lay.minimumInteritemSpacing
//        return CGSize(width:widthPerItem, height:300)
//    }
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "BigImageVC") as? BigImageVC
//        vc?.image = fullImagearr[indexPath.row]
//        navigationController?.pushViewController(vc!, animated: false)
//    }
//    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        if indexPath.row == fullImagearr.count - 1 {
//            page = page + 1
//            apicalling()
//        }
//    }
    
}
