//
//  ProductCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class ProductCell: UITableViewCell {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var btnSeAll: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var backView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prePareCell()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension ProductCell{
    func prePareCell(){
        backView.backgroundColor = .clear
        collectionView.delegate = self
        collectionView.dataSource = self
        
        lblTitle.font = UIFont.systemFont(ofSize: 20.0)
        lblTitle.textColor = .white
        
        
        registationCell()
    }
    func registationCell(){
        
        self.collectionView.register(UINib(nibName: "ProductCellectionCell", bundle: nil), forCellWithReuseIdentifier: "ProductCellectionCell")
        
    }
}
extension ProductCell : UICollectionViewDelegate ,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : ProductCellectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCellectionCell", for: indexPath) as! ProductCellectionCell
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1.0, left: 1.0, bottom: 1.0, right: 1.0)//here your custom value for spacing
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let lay = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 2 - lay.minimumInteritemSpacing
        return CGSize(width:widthPerItem, height:300)
    }
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "BigImageVC") as? BigImageVC
//        vc?.image = fullImagearr[indexPath.row]
//        navigationController?.pushViewController(vc!, animated: false)
//    }
//    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        if indexPath.row == fullImagearr.count - 1 {
//            page = page + 1
//            apicalling()
//        }
//    }
    
}
