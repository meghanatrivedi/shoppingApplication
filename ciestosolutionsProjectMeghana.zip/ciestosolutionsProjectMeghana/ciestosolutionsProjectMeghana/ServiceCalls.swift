//
//  ServiceCalls.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit
import Alamofire

class ServiceCalls: NSObject {
    static let sharedInstance: ServiceCalls = {
            let instance = ServiceCalls()

            return instance
        }()
    
    
   // /for post request with header values
        func PostAPICallWithHeaderValues (url: String, postData: [String: Any]!, headersData: [String: Any]!, completionHandler:@escaping ( _ success: Bool, _ resultVal: [String: Any]) -> Void) {

            AF.request(url, method: .post, parameters: postData, encoding: JSONEncoding.default, headers: headersData as? HTTPHeaders).responseJSON { (response) in

                if let json = response.result as? [String: Any] {
                    completionHandler(true, json)
                } else {
                    completionHandler(false, [:])
                    }
            }
           }

}
