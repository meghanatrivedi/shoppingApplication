//
//  ViewController.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    @IBOutlet weak var mainHeaderView: UIView!
    @IBOutlet weak var imgMenu: UIImageView!
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgSearch: UIImageView!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        prePareUI()
        // apiCalling()
        // apiswiftyjsoncalling()
        let json: [String: Any] = ["AccessKey" : "456", "User_Id" : "166", "Keyword" : "", "Type" : "Simple"]
        
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        
        // create post request
        let url = URL(string: "https://snkrgram.com/x-admin/search")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let headers: [String : String] = [
            "Content-Type": "multipart/form-data",
            "Accept": "*/*",
            "Accept-Encoding":"gzip, deflate, br"
        ]
        request.allHTTPHeaderFields = headers
        
        // insert json data to the request
        request.httpBody = jsonData
        
//
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            print(response!)
            do {
                let json = try JSONSerialization.jsonObject(with: data!) as! Dictionary<String, AnyObject>
                print(json)
            } catch {
                print("error")
            }
        })
        
        task.resume()
        // Do any additional setup after loading the view.
    }
    
    
}
extension ViewController{
    @IBAction func btnMenuClick(_ sender: UIButton) {
        print("Menu button click")
    }
    
    @IBAction func btnSearchClick(_ sender: UIButton) {
        print("Search button click")
    }
}
extension ViewController{
    func prePareUI(){
        
        self.view.backgroundColor = #colorLiteral(red: 0.001932211686, green: 0, blue: 0.1080451831, alpha: 1)
        imgMenu.tintColor = .white
        imgSearch.tintColor = .white
        lblTitle.font = UIFont.systemFont(ofSize: 20.0)
        lblTitle.textColor = .white
        lblTitle.text = "Home"
        lblTitle.textAlignment = .center
        
        tableView.backgroundColor = .clear
        tableView.tableFooterView = UIView()
        
        
        tableView.register(UINib(nibName: "OfferCell", bundle: nil), forCellReuseIdentifier: "OfferCell")
        tableView.register(UINib(nibName: "TopCategoriesCell", bundle: nil), forCellReuseIdentifier: "TopCategoriesCell")
        
        tableView.register(UINib(nibName: "ProductCell", bundle: nil), forCellReuseIdentifier: "ProductCell")
        tableView.register(UINib(nibName: "PropulerItemCell", bundle: nil), forCellReuseIdentifier: "PropulerItemCell")
        
        
        
    }
}
extension ViewController : UITableViewDelegate ,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row{
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "OfferCell", for: indexPath) as! OfferCell
            
            
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TopCategoriesCell", for: indexPath) as! TopCategoriesCell
            
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.lblTitle.text = "New Releses"
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "OfferCell", for: indexPath) as! OfferCell
            
            
            return cell
        case 4:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.lblTitle.text = "Product for you"
            return cell
        case 5:
            let cell = tableView.dequeueReusableCell(withIdentifier: "OfferCell", for: indexPath) as! OfferCell
            
            return cell
        case 6:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.lblTitle.text = "Propuler Items"
            
            let layout = UICollectionViewFlowLayout()
            layout.scrollDirection = .vertical
            cell.collectionView.collectionViewLayout = layout
            return cell
        default:
            return UITableViewCell()
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row{
        case 0:
            return 280
        case 1:
            return 180
        case 2:
            return 370
        case 3:
            return 280
        case 4:
            return 400
        case 5:
            return 280
        case 6:
            return 580
        default:
            return UITableView.automaticDimension
        }
    }
    
    
}
extension ViewController{
    func apiswiftyjsoncalling(){
        
        
        var urlRequest = URLRequest(url: URL(string: "https://snkrgram.com/x-admin/search")!)
        urlRequest.httpMethod = "post"
        let dataDictionary =  ["AccessKey" : "456", "User_Id" : "166", "Keyword" : "", "Type" : "Simple"]
        
        do {
            let requestBody = try JSONSerialization.data(withJSONObject: dataDictionary, options: .prettyPrinted)
            
            urlRequest.httpBody = requestBody
            urlRequest.addValue("application/json", forHTTPHeaderField: "content-type") //this line is very important as explained in the video
        } catch let error {
            debugPrint(error.localizedDescription)
        }
        
        URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in
            
            if(data != nil && data?.count != 0)
            {
                //use decodable here to parse the json response, if you are new to decodable then watch the video
                //decodable video: https://youtu.be/RiuvxmoU37E
                let response = String(data: data!, encoding: .utf8)
                print(response!)
            }
        }.resume()
    }
    func apiCalling(){
        //  let parameters: [String: Any] = ["AccessKey" : "456", "User_Id" : "166", "Keyword" : "", "Type" : "Simple"]
        //let urlString = "https://snkrgram.com/x-admin/search"
        // let headers = ["Content-Type": "application/json"]
        print("api acalling")
        
        // declare the parameter as a dictionary that contains string as key and value combination. considering inputs are valid
        
        let parameters: [String: Any] =  ["AccessKey" : "456", "User_Id" : "166", "Keyword" : "", "Type" : "Simple"]
        
        // create the url with URL
        let url = URL(string: "https://snkrgram.com/x-admin/search")! // change server url accordingly
        
        // create the session object
        let session = URLSession.shared
        
        // now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "POST" //set http method as POST
        
        // add headers for the request
        request.addValue("application/json", forHTTPHeaderField: "Content-Type") // change as per server requirements
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        do {
            // convert parameters to Data and assign dictionary to httpBody of request
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
        } catch let error {
            print(error.localizedDescription)
            return
        }
        
        // create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request) { data, response, error in
            print(data)
            print(response)
            print(error)
            if let error = error {
                print("Post Request Error: \(error.localizedDescription)")
                return
            }
            
            // ensure there is valid response code returned from this HTTP response
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode)
            else {
                print("Invalid Response received from the server")
                return
            }
            
            // ensure there is data returned
            guard let responseData = data else {
                print("nil Data received from the server")
                return
            }
            
            do {
                // create json object from data or use JSONDecoder to convert to Model stuct
                if let jsonResponse = try JSONSerialization.jsonObject(with: responseData, options: .mutableContainers) as? [String: Any] {
                    print(jsonResponse)
                    // handle json response
                } else {
                    print("data maybe corrupted or in wrong format")
                    throw URLError(.badServerResponse)
                }
            } catch let error {
                print(error.localizedDescription)
            }
        }
        // perform the task
        task.resume()
        
        //        AF.request("https://snkrgram.com/x-admin/search", method: .post, parameters: parameters, encoding: JSONEncoding.default)
        //            .responseJSON { response  in
        //                print(response)
        //
        //
        //            }
    }
}
