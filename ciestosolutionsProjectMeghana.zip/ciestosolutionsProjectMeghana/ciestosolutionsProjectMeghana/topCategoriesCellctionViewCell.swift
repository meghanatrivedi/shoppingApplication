//
//  topCategoriesCellctionViewCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class topCategoriesCellctionViewCell: UICollectionViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var clothBackView: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prePareCell()
        // Initialization code
    }

}
extension topCategoriesCellctionViewCell{
    func prePareCell(){
        backView.backgroundColor = .clear
        
        clothBackView.backgroundColor = .blue
        clothBackView.layer.cornerRadius = clothBackView.frame.height / 2
        
        
        imageView.tintColor = .white
        
        label.textColor = .white
        
    }
}
