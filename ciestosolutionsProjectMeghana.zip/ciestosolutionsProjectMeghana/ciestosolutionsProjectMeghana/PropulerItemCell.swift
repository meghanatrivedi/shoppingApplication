//
//  PropulerItemCell.swift
//  ciestosolutionsProjectMeghana
//
//  Created by Meghna on 08/03/22.
//

import UIKit

class PropulerItemCell: UITableViewCell {
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prePareUI()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
extension PropulerItemCell{
    func prePareUI(){
        backView.backgroundColor = .clear
        
        tableView.backgroundColor = .clear
        tableView.tableFooterView = UIView()

        
        tableView.register(UINib(nibName: "PropulerItemTableCell", bundle: nil), forCellReuseIdentifier: "PropulerItemTableCell")

    }
}
 
extension PropulerItemCell : UITableViewDelegate ,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PropulerItemTableCell", for: indexPath) as! PropulerItemTableCell
        return cell
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 150
//    }
    
    
}
